import { useState } from 'react';
import { motion } from 'motion/react';
import { UserPlus, FileText, CheckCircle2, AlertCircle } from 'lucide-react';

export default function Registration() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    companyName: '',
    password: ''
  });

  const handleOnlineSignup = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API registration call
    setTimeout(() => {
      setStep(2);
    }, 1000);
  };

  return (
    <div className="bg-slate-50 min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-12">
          <h1 className="text-4xl font-sans font-extrabold text-chamber-navy mb-4">Member Registration</h1>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto">
            Join the Amajuba Economic Chamber of Commerce. Please create your online profile before downloading and submitting the formal registration documents.
          </p>
        </div>

        {/* Process Stepper */}
        <div className="flex justify-center items-center mb-12">
          <div className={`flex flex-col items-center ${step >= 1 ? 'text-chamber-blue' : 'text-slate-400'}`}>
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 mb-2 ${step >= 1 ? 'border-chamber-blue bg-blue-50' : 'border-slate-300 bg-white'}`}>
              <UserPlus size={24} />
            </div>
            <span className="text-sm font-medium">1. Online Signup</span>
          </div>
          <div className={`w-24 h-1 mx-4 rounded-full ${step >= 2 ? 'bg-chamber-blue' : 'bg-slate-200'}`}></div>
          <div className={`flex flex-col items-center ${step >= 2 ? 'text-chamber-blue' : 'text-slate-400'}`}>
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 mb-2 ${step >= 2 ? 'border-chamber-blue bg-blue-50' : 'border-slate-300 bg-white'}`}>
              <FileText size={24} />
            </div>
            <span className="text-sm font-medium">2. Official Form</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          {step === 1 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="p-8 md:p-12"
            >
              <div className="flex items-start gap-4 p-4 mb-8 bg-amber-50 border-l-4 border-chamber-gold rounded-r-md">
                <AlertCircle className="text-chamber-gold shrink-0 mt-0.5" size={20} />
                <p className="text-sm text-amber-900 font-medium leading-relaxed">
                  Important: All new members must sign up for an online account here before completing the final registration form.
                </p>
              </div>

              <form onSubmit={handleOnlineSignup} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">First Name</label>
                    <input 
                      type="text" required
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-chamber-blue outline-none text-sm"
                      value={formData.firstName} onChange={e => setFormData({...formData, firstName: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Last Name</label>
                    <input 
                      type="text" required
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-chamber-blue outline-none text-sm"
                      value={formData.lastName} onChange={e => setFormData({...formData, lastName: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Company / Enterprise Name</label>
                  <input 
                    type="text" required
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-chamber-blue outline-none text-sm"
                    value={formData.companyName} onChange={e => setFormData({...formData, companyName: e.target.value})}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Email Address</label>
                    <input 
                      type="email" required
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-chamber-blue outline-none text-sm"
                      value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Phone Number</label>
                    <input 
                      type="tel" required
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-chamber-blue outline-none text-sm"
                      value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">Create Password</label>
                  <input 
                    type="password" required minLength={8}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-chamber-blue outline-none text-sm"
                    value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})}
                  />
                  <p className="text-xs text-slate-500 mt-2">Must be at least 8 characters long.</p>
                </div>

                <button 
                  type="submit"
                  className="w-full py-4 mt-6 bg-chamber-navy text-white rounded-2xl font-bold text-lg hover:bg-slate-800 transition-colors shadow-xl shadow-chamber-navy/30 flex items-center justify-center gap-2"
                >
                  Create Online Profile <ArrowRightIcon className="w-5 h-5" />
                </button>
              </form>
            </motion.div>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-8 md:p-16 text-center"
            >
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 size={40} />
              </div>
              <h2 className="text-3xl font-bold text-chamber-navy mb-4">Profile Created Successfully!</h2>
              <p className="text-lg text-slate-600 mb-8 max-w-lg mx-auto">
                Welcome, {formData.firstName}. Your online account for {formData.companyName} has been established. You must now complete the official registration form to finalize your membership.
              </p>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-8 max-w-md mx-auto">
                <FileText className="w-12 h-12 text-chamber-blue mx-auto mb-4" />
                <h3 className="text-xl font-bold text-slate-800 mb-2">Official Registration Form</h3>
                <p className="text-slate-500 text-sm mb-6">Download, sign, and return to admin@amajubaeconomicchamber.org</p>
                
                <button 
                  onClick={() => alert("Downloading AECC_Registration_Form.pdf...")} 
                  className="w-full py-3 bg-chamber-gold text-white font-bold rounded-md hover:bg-amber-500 transition-colors shadow-sm"
                >
                  Download Form (PDF)
                </button>
              </div>
            </motion.div>
          )}
        </div>
        
      </div>
    </div>
  );
}

function ArrowRightIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
    </svg>
  );
}
