import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Pickaxe, Factory, ShoppingCart, ArrowRight } from 'lucide-react';

export default function Home() {
  const sectors = [
    {
      title: 'Primary Sector',
      icon: <Pickaxe size={32} className="text-chamber-blue" />,
      description: 'Focused on extraction and raw materials including Agriculture and Mining to provide foundational resources.',
      color: 'bg-blue-50',
    },
    {
      title: 'Secondary Sector',
      icon: <Factory size={32} className="text-chamber-blue" />,
      description: 'Focused on manufacturing and processing, including Steel, Textiles, Chemicals, and Industrial processing.',
      color: 'bg-slate-50',
    },
    {
      title: 'Tertiary Sector',
      icon: <ShoppingCart size={32} className="text-chamber-blue" />,
      description: 'Focused on services, distribution, retail, professional services, and logistics ensuring robust service delivery.',
      color: 'bg-blue-50',
    }
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden bg-slate-50">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full blur-3xl opacity-50 -z-10 translate-x-32 -translate-y-32"></div>
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2940&auto=format&fit=crop')] bg-cover bg-center opacity-[0.03] mix-blend-overlay"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-chamber-gold/20 text-chamber-lightgold border border-chamber-gold/50 font-medium text-sm tracking-widest uppercase mb-8 shadow-sm">
              Amajuba District, KwaZulu-Natal
            </span>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-sans font-extrabold text-chamber-navy leading-[1.1] mb-6 shadow-transparent">
              Promoting Growth & <span className="text-chamber-gold">Prosperity</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
              We serve as a catalyst for sustainable economic development across the Amajuba District, transforming dialogue into action and shared understanding into measurable progress.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/register"
                className="w-full sm:w-auto px-8 py-3 bg-chamber-navy text-white font-semibold rounded-full hover:bg-slate-800 transition-colors shadow-lg shadow-chamber-navy/20 text-lg flex items-center justify-center gap-2 group"
              >
                Become a Member
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/about"
                className="w-full sm:w-auto px-8 py-3 bg-white text-slate-600 font-semibold rounded-full hover:text-chamber-navy transition-colors shadow-sm text-lg border border-slate-200"
              >
                Learn More
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Core Sectors */}
      <section className="py-24 bg-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-chamber-navy mb-4">Our Economic Development Framework</h2>
            <div className="w-24 h-1 bg-chamber-gold mx-auto mb-6 rounded-full"></div>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Our strategy is organized across three interconnected economic sectors, aligned with standard economic classification to drive transformation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {sectors.map((sector, index) => (
              <motion.div
                key={sector.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className={`${sector.color} rounded-2xl p-8 border border-slate-100 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden group`}
              >
                <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center shadow-sm mb-6 group-hover:scale-110 transition-transform">
                  {sector.icon}
                </div>
                <h3 className="text-xl font-bold text-chamber-navy mb-3">{sector.title}</h3>
                <p className="text-slate-600 leading-relaxed">
                  {sector.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Value Prop Banner */}
      <section className="py-20 bg-chamber-blue text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10 mix-blend-overlay"></div>
        <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-balance">
          <h2 className="text-2xl md:text-4xl font-serif font-medium leading-relaxed italic">
            "Developing integrated competence—woven from knowledge, skills, and attitudes—to driven economic transformation and sustainable livelihoods across all sectors within 3-5 years."
          </h2>
          <div className="mt-8 flex justify-center">
            <Link
              to="/about"
              className="text-white border-b border-chamber-gold bg-transparent pb-1 hover:text-chamber-lightgold transition-colors font-medium"
            >
              Read our full strategic framework
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
