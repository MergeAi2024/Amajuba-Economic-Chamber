import { motion } from 'motion/react';
import { Target, Users, Map, Layers } from 'lucide-react';

export default function About() {
  const footprint = ['Dannhauser', 'Utrecht', 'Osizweni', 'Madadeni', 'Newcastle', 'Charlestown'];

  return (
    <div className="bg-slate-50 min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-chamber-blue font-bold tracking-wider uppercase text-sm mb-2 block">Who We Are</span>
          <h1 className="text-4xl md:text-5xl font-sans font-extrabold text-chamber-navy mb-6">About the Chamber</h1>
          <div className="w-24 h-1 bg-chamber-gold mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center mb-24">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="prose prose-lg text-slate-600"
          >
            <p className="lead text-xl text-chamber-navy font-medium mb-6">
              The Amajuba Economic Chamber serves as a catalyst for sustainable economic development across the Amajuba District.
            </p>
            <p className="mb-4">
              We operate through a structured governance framework and implement targeted sectoral interventions aimed at strengthening economic participation, promoting local enterprise development, and driving inclusive growth. 
            </p>
            <p>
              Our mandate is centred on transformation, sustainability, and structured collaboration across all sectors of the economy. We convene leaders from business, government, civil society, and academia to transform dialogue into action.
            </p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="bg-white p-8 md:p-12 rounded-2xl shadow-sm border border-slate-100"
          >
            <h3 className="text-2xl font-bold font-serif text-chamber-navy mb-6 flex items-center gap-3">
              <Target className="text-chamber-gold" size={28} />
              Core Value Proposition
            </h3>
            <p className="text-lg italic text-slate-700 leading-relaxed border-l-4 border-chamber-blue pl-6 py-2">
              "Developing integrated competence—woven from knowledge, skills, and attitudes—to driven economic transformation and sustainable livelihoods across all sectors within 3-5 years."
            </p>
          </motion.div>
        </div>

        {/* How We Work & Footprint */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-8">
            <h3 className="text-2xl font-bold text-chamber-navy mb-6 flex items-center gap-3">
              <Layers className="text-chamber-blue" size={24} />
              How We Work
            </h3>
            <ul className="space-y-4">
              {[
                'Foresight and strategic planning',
                'Structured dialogue between stakeholders',
                'Cooperation across public and private sectors',
                'Practical, measurable solutions'
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-4">
                  <div className="h-6 w-6 rounded-full bg-blue-50 text-chamber-blue flex items-center justify-center shrink-0 mt-0.5">
                    <div className="w-2 h-2 rounded-full bg-chamber-blue"></div>
                  </div>
                  <span className="text-slate-700">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="bg-chamber-navy text-white rounded-xl shadow-sm p-8 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Map size={120} />
            </div>
            <div className="relative z-10">
              <h3 className="text-2xl font-bold font-serif text-chamber-lightgold mb-6 flex items-center gap-3">
                <Users className="text-white" size={24} />
                Our Regional Footprint
              </h3>
              <p className="text-slate-300 mb-6">
                We actively engage across the district, bringing together stakeholders to identify challenges, exchange insights, and advance a shared economic agenda in:
              </p>
              <div className="flex flex-wrap gap-3">
                {footprint.map(area => (
                  <span key={area} className="px-4 py-2 bg-white/10 rounded-full text-sm font-medium border border-white/20">
                    {area}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
